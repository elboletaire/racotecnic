<!--
        index.php
        
        Copyright 2009 El Boletaire <elboletaire@underave.net>
        
        This program is free software; you can redistribute it and/or modify
        it under the terms of the GNU General Public License as published by
        the Free Software Foundation; either version 2 of the License, or
        (at your option) any later version.
        
        This program is distributed in the hope that it will be useful,
        but WITHOUT ANY WARRANTY; without even the implied warranty of
        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
        GNU General Public License for more details.
        
-->

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="es" lang="es">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<title>Transición de imágenes aleatorias de Gallery2 con jQuery</title>
		<style type="text/css">
			.one-image {
				float: left;
				padding-left: .7em;
			}
			a img {
				border: none;
			}
			#capa, #subcapa {
				position: absolute;
				top: 1em;
				left: .6em;
			}
		</style>
		<script type="text/javascript" src="jquery-1.3.2.min.js"></script>
		<script type="text/javascript">
		<!--
			function randomImages(){
					$("#subcapa").load('random_image.php').hide();
					$("#capa").fadeOut(2000, function(){
						$(this).hide();
						$("#capa").html($("#subcapa").html()).fadeIn(2000);
					});
			}
			setInterval("randomImages()", 7000);
		-->
		</script>
	</head>
	<body>
	<div id="capa">
	<?php
		include 'random_image.php';
	?>
	</div>
	<div id="subcapa"></div>
</body>
</html>
