<?php
/*
	ESTA ES LA VERSIÓN QUE SE UTILIZA PARA EMBEDIR LA GALERIA SEGUN EL CODEX
		require_once(dirname(__FILE__) . '/galeria/embed.php');
		$ret = GalleryEmbed::init(array('fullInit' => true, 'embedUri' => '/', 'g2Uri' => 'http://vuestra.galeria.com/main.php'));
		if ($ret) {
			print 'GalleryEmbed::init failed, here is the error message: ' . $ret->getAsHtml();
			exit;
		}
		list ($ret, $bodyHtml, $headHtml) = GalleryEmbed::getImageBlock(array('blocks' => 'randomImage|randomImage|randomImage',
		                                                             'show' => 'none', 'maxSize' => 130));
		if ($ret) {
			print 'GalleryEmbed::getImageBlock failed, here is the error message: ' . $ret->getAsHtml();
			exit;
		}
		
		print $bodyHtml;

*/
/* ESTA OTRA LA ENCONTRÁIS EN LA AYUDA DEL MÓDULO IMAGEBLOCK */
@readfile('http://vuestra.galeria.com/main.php?g2_view=imageblock.External&g2_blocks=randomImage|randomImage|randomImage&g2_show=none&g2_maxSize=130');
?>
