<?= '<?xml version="1.1" encoding="' . Configure::read('App.encoding') . '"?>' ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="es-es">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
    	<?= $html->charset(); ?>
		<title><?= $title_for_layout ?> | Ejemplos CakePHP | Racó Tècnic</title>
		<?= $javascript->link(array('jquery-1.3.2.min','jquery.gritter.min')) ?>
		<?= $javascript->codeBlock('var webroot="'.$this->webroot.'";') ?>
		<?= $scripts_for_layout; ?>
		<?= $html->css(array('main','gritter')) ?>
	</head>
<body>
	<div id="container">
		<div id="header">
			<h1><?php echo $html->link(__('Ejemplos CakePHP, Racó Tècnic', true), 'http://racotecnic.underave.net'); ?></h1>
		</div>
		<div id="content">
			<?php $session->flash(); ?>
			<?= $content_for_layout; ?>
		</div>
		<div id="footer">
			<?php echo $html->link(
					$html->image('cake.power.gif', array('alt'=> __("CakePHP: the rapid development php framework", true), 'border'=>"0")),
					'http://www.cakephp.org/',
					array('target'=>'_blank'), null, false
				);
			?>
		</div>
	</div>
	<?php echo $cakeDebug; ?>
	<script src="http://static.woopra.com/js/woopra.js" type="text/javascript"></script>
</body>
</html>