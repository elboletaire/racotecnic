<?= $javascript->codeBlock('
$(function(){
	$.gritter.add({
		title: "' . __("Error",true) . '",
		text: "' . $content_for_layout . '",
		image: webroot + "img/error_48.png",
		sticky: true
	});
});') ?>