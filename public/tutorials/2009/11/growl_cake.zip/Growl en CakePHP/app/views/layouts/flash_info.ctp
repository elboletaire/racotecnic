<?= $javascript->codeBlock('
$(function(){
	$.gritter.add({
		title: "' . __("Información",true) . '",
		text: "' . $content_for_layout . '",
		image: webroot + "img/info_48.png",
		sticky: true
	});
});') ?>