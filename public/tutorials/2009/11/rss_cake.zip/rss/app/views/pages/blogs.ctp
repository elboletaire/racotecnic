<?php $javascript->link('page_specific/blogs',false) ?>
<p><?php echo $html->link('Leer hilos RSS en CakePHP utilizando jQuery','http://racotecnic.underave.net/2009/11/leer-hilos-rss-en-cakephp-utilizando-jquery') ?></p>
<?php echo $html->link($html->image('http://www.underave.net/barna23/img/blogs/raco.png', array('alt'=>'Racó Tècnic', 'class'=>'titol_blog')),'http://racotecnic.underave.net',array('target'=>'_blank'),false,false) ?>
<ul class="blogs" id="raco">
	<li><?php __("Cargando") ?>...</li>
</ul>
<?php echo $html->link($html->image('http://www.underave.net/barna23/img/blogs/unde.png', array('alt'=>'Underave\'s Blog: Be underground', 'class'=>'titol_blog')),'http://blog.underave.net',null,false,false) ?>
<ul class="blogs" id="underave">
	<li><?php __("Cargando") ?>...</li>
</ul>
<?php echo $html->link($html->image('http://www.underave.net/barna23/img/blogs/zeta.png', array('alt'=>'Plan [Zeta]', 'class'=>'titol_blog')),'http://planzeta.underave.net',array('target'=>'_blank'),false,false) ?>
<ul class="blogs" id="zeta">
	<li><?php __("Cargando") ?>...</li>
</ul>
<?php echo $html->link($html->image('http://www.underave.net/barna23/img/blogs/psico.png', array('alt'=>'Psico Actividad', 'class'=>'titol_blog')),'http://psicoactividad.underave.net',array('target'=>'_blank'),false,false) ?>
<ul class="blogs" id="psico">
	<li><?php __("Cargando") ?>...</li>
</ul>