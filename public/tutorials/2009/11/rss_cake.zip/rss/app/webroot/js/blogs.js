$(function(){
	var blogs = ['underave','zeta','psico','raco'];
	$.each(blogs, function(i, blog){
		$.getJSON(webroot+'rss/'+blog,function(data){
			$('#'+blog).fadeOut('normal',function(){
				$(this).html('').css('background','none');
				$.each(data, function(i, item){
					$('<li><a href="'+item.link+'" target="_top">'+item.title.substr(0,1).toUpperCase() + item.title.substr(1,item.title.length).toLowerCase()+'</a></li>').appendTo("#"+blog);
				});
				$(this).fadeIn('normal');
			});
		});
	});
});