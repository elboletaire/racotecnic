<?php 
class PagsController extends AppController
{
	var $paginate = array('limit' => 4);
	var $helpers = array('Javascript');
	
	public function index()
	{
		$this->set('pags', $this->paginate());
	}
}