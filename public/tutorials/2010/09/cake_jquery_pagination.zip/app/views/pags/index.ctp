<?php
$script = '
jQuery(function($) {
	$.history.init(function(url){
		if ( url == "" ) return false; 
		$.ajax({
			type: "GET",
			url: url,
			dataType: "html",
			success: function(data) {
				$("#pags").html($(data).find("#pags"));
			}
		});
	});

	$("a[href*=/page:]").live("click", function(e) {
		$.history.load($(this).attr("href"));
		e.preventDefault(); // return false;
	});
});
';
$this->Javascript->link(array('jquery-1.4.2.min', 'jquery.history'), false);
$this->Javascript->codeBlock($script, array('inline' => false));
?>
<table id="pags">
	<thead>
		<tr>
			<th><?php echo $paginator->sort('id') ?></th>
			<th><?php echo $paginator->sort('title') ?></th>
			<th><?php echo $paginator->sort('conent') ?></th>
			<th><?php echo $paginator->sort('created') ?></th>
			<th><?php echo $paginator->sort('modified') ?></th>
		</tr>
	</thead>
	<tbody>
		<?php foreach ( $pags as $pag ): ?>
		<tr>
			<td><?php echo $pag['Pag']['id'] ?></td>
			<td><?php echo $pag['Pag']['title'] ?></td>
			<td><?php echo $pag['Pag']['conent'] ?></td>
			<td><?php echo $pag['Pag']['created'] ?></td>
			<td><?php echo $pag['Pag']['modified'] ?></td>
		</tr>
		<?php endforeach ?>
		<tr>
			<td><?php echo $paginator->prev('« Anterior') ?></td>
			<td colspan="3"><?php echo $paginator->numbers() ?></td>
			<td><?php echo $paginator->next('Siguiente »') ?></td>
		</tr>
	</tbody>
</table>